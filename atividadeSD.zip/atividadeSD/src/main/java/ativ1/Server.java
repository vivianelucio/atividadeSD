
package ativ1;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.util.StringTokenizer;


public class Server {
    public static void main(String[] args) throws IOException {
        DatagramSocket aSocket = null;
        aSocket = new DatagramSocket(6789);
        System.out.println("Servidor UDP iniciado");
        byte[] buffer = new byte[100];
        
        while (true){
            DatagramPacket request = new DatagramPacket(buffer,buffer.length);
            
            aSocket.receive(request);
            
            String operacao = new String (request.getData());
            operacao=operacao.trim();
            StringTokenizer st = new StringTokenizer(operacao);
            float op1=Float.parseFloat(st.nextToken());
            String operando =st.nextToken();
            float op2=Float.parseFloat(st.nextToken());
            float result = 0 ;
            switch (operando){
                case "+":
                    result = op1 + op2;
                    break;
                case "-":
                    result = op1 - op2;
                    break;
                case "*":
                    result = op1 * op2;
                    break;
                case "/":
                    result = op1 / op2;
                    break;                      
            }     
            
            System.out.println("RECEIVE= " + new String (request.getData()) );
            
            String msgString = new String("O Resultado da operação ")+ new String(operacao) + new String(" = ") + result ;
            
            byte[] msg = msgString.getBytes();
            DatagramPacket reply = new DatagramPacket(msg,msgString.length(),request.getAddress(),request.getPort());
            aSocket.send(reply);
        }
    }
}
