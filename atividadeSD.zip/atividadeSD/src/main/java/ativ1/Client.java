
package ativ1;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.Scanner;


public class Client {
    public static void main(String[] args) throws IOException {
        String servidorIP = "localhost";
        Scanner scanner = new Scanner(System.in);        
        System.out.println("Entre com a expressao:");
        //String msg = "25 + 5";
        
        String msg = scanner.nextLine();
        //System.out.println("xxx" + msg + "xxx");
        msg = new String(msg);
        DatagramSocket aSocket = new DatagramSocket();
        
        byte[] m = msg.getBytes();
        InetAddress aHost = InetAddress.getByName(servidorIP);
        int serverPort =6789;
        DatagramPacket request = new DatagramPacket (m, msg.length(), aHost,serverPort);
        aSocket.send(request);
        byte[] buffer = new byte[100];
        DatagramPacket reply = new DatagramPacket(buffer, buffer.length);
        aSocket.receive(reply);
        System.out.println("Reply: " + new String(reply.getData()) );
        aSocket.close();    
    }     
}

