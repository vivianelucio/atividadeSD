
package ativ2;

import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.List;


public interface InterfaceVeiculos extends Remote {

    public List<Veiculo> search2Ano(int i) throws RemoteException;

    public void add(Veiculo veiculo) throws RemoteException;
   
}


