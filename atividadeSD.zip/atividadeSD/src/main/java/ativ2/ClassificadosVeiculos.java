
package ativ2;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayList;
import java.util.List;

public class ClassificadosVeiculos extends UnicastRemoteObject implements InterfaceVeiculos {
    private List<Veiculo> veiculo;

    public ClassificadosVeiculos() throws RemoteException {
        super();
        this.veiculo= new ArrayList<>();
    }

    @Override
    public List<Veiculo> search2Ano(int anoVeiculo) throws RemoteException {
        List<Veiculo> result = new ArrayList<>();
        for (Veiculo v : veiculo) {
            if (v.getAno() == anoVeiculo) {
                result.add(v);
            }
        }
        return result;
    }

    @Override 
    public void add(Veiculo v) throws RemoteException {
        veiculo.add(v);
    }
}