
package ativ2;

import java.io.Serializable;


public class Veiculo implements Serializable {
    String nomeCliente;
    String marcaVeiculo;
    double valorVenda;
    int ano;

 public Veiculo(String nomeCliente, String marcaVeiculo, double valorVenda, int ano) {
        this.nomeCliente = nomeCliente;
        this.marcaVeiculo = marcaVeiculo;
        this.valorVenda = valorVenda;
        this.ano = ano;
    }

    public String getNomeCliente() {
        return nomeCliente;
    }

    public String getMarcaVeiculo() {
        return marcaVeiculo;
    }

    public double getValorVenda() {
        return valorVenda;
    }

    public int getAno() {
        return ano;
    }
}    
    
    

