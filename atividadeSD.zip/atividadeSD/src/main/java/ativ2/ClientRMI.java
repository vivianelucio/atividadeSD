
package ativ2;

import java.rmi.Naming;
import java.util.List;
import javax.swing.JOptionPane;

public class ClientRMI {
    public static void main(String[] args) throws Exception {
        String objName = "rmi://localhost:1099/Classif";
        InterfaceVeiculos classif = (InterfaceVeiculos) Naming.lookup(objName);
        boolean ligado =true;
        
        while(ligado ==true){
            
        
       String escolha = JOptionPane.showInputDialog("Digite uma das opções:\n"
                                                             + "1 - Adicionar Veículo.\n" +  "2 - Ver Lista.\n" + "3 - Sair.\n");

       
       switch(escolha){
           case "1":
        String nomeCliente = JOptionPane.showInputDialog("Digite o nome do cliente:");
        String marcaVeiculo = JOptionPane.showInputDialog("Digite a marca do veículo:");
        double valorVenda = Double.parseDouble(JOptionPane.showInputDialog("Digite o valor de venda do veículo:"));
        int ano = Integer.parseInt(JOptionPane.showInputDialog("Digite o ano do veículo:"));

       
        Veiculo veiculo = new Veiculo(nomeCliente, marcaVeiculo, valorVenda, ano);

        classif.add(veiculo);
        JOptionPane.showMessageDialog(null, "Veículo adicionado:\n"
                                            + "Nome do cliente: " + veiculo.getNomeCliente() + "\n"
                                            + "Marca do veículo: " + veiculo.getMarcaVeiculo() + "\n"
                                            + "Valor de venda: " + veiculo.getValorVenda() + "\n"
                                            + "Ano do veículo: " + veiculo.getAno());
         break;
        case "2":
        ano = Integer.parseInt(JOptionPane.showInputDialog("Digite o ano do veículo: "));
        List<Veiculo> result = classif.search2Ano(ano);
        String message = "Resultados da busca: \n";
        for (Veiculo v : result) {
        message += v.getNomeCliente() + " - " + v.getMarcaVeiculo() + " - " + v.getValorVenda() + "\n";
        }
JOptionPane.showMessageDialog(null, message);
break;
           case "3":
               ligado = false;
               break;
    }
}

    }
}