
package ativ2;

import java.rmi.Naming;
import java.rmi.Remote;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;


public class ServerRMI {
    public static void main(String[] args) {
        try {
            ClassificadosVeiculos classif = new ClassificadosVeiculos();
            String objName = "rmi://localhost/Classif";
            LocateRegistry.createRegistry(1099);
            Naming.rebind(objName, (Remote) classif);
            System.out.println("Objeto registrado com sucesso: " + objName);
        } catch (RemoteException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
